struct Line{
	int x1,y1,z1,x2,y2,z2;
	float r,g,b;
	int state;
	int total;
};
struct Point3D{
    int x1,y1,z1;
};
struct Point2D{
    int x1,y1,x2,y2;
};
